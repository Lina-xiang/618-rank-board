import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { feishuConfig, syncLogs, dataSnapshots } from "@db/schema";
import {
  getTenantAccessToken,
  getAllBitableRecords,
  extractFieldValue,
  extractNumberValue,
} from "../lib/feishu";

export const feishuRouter = createRouter({
  getConfig: publicQuery.query(async () => {
    const db = getDb();
    const configs = await db.query.feishuConfig.findMany({
      where: eq(feishuConfig.isActive, 1),
    });
    return configs[0] || null;
  }),

  saveConfig: publicQuery
    .input(
      z.object({
        appId: z.string().min(1),
        appSecret: z.string().min(1),
        appToken: z.string().min(1),
        tableId: z.string().min(1),
        fieldMapping: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const db = getDb();

        // 先把所有旧配置设为 inactive
        await db.update(feishuConfig).set({ isActive: 0 }).where(eq(feishuConfig.isActive, 1));

        // 插入新配置
        const result = await db.insert(feishuConfig).values({
          appId: input.appId,
          appSecret: input.appSecret,
          appToken: input.appToken,
          tableId: input.tableId,
          fieldMapping: input.fieldMapping,
          isActive: 1,
        });

        const insertId = result[0]?.insertId;
        const id = typeof insertId === "bigint" ? Number(insertId) : Number(insertId);

        return { success: true as const, id };
      } catch (err: any) {
        console.error("[saveConfig] error:", err);
        throw new Error("保存配置失败: " + (err.message || "未知错误"));
      }
    }),

  testConnection: publicQuery
    .input(
      z.object({
        appId: z.string().min(1),
        appSecret: z.string().min(1),
        appToken: z.string().min(1),
        tableId: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const token = await getTenantAccessToken(input.appId, input.appSecret);
        const records = await getAllBitableRecords(input.appToken, input.tableId, token);
        const sampleFields = records.length > 0 ? Object.keys(records[0].fields) : [];
        return {
          success: true as const,
          totalRecords: records.length,
          sampleFields,
          sampleRecord: records.length > 0 ? records[0].fields : null,
        };
      } catch (error: any) {
        return { success: false as const, error: error.message };
      }
    }),

  sync: publicQuery
    .input(z.object({ configId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();

      const config = await db.query.feishuConfig.findFirst({
        where: eq(feishuConfig.id, input.configId),
      });
      if (!config) return { success: false, error: "配置不存在" };

      const logResult = await db.insert(syncLogs).values({
        configId: input.configId,
        status: "running",
        startedAt: new Date(),
      });
      const logId = Number(logResult[0]?.insertId ?? 0);

      try {
        const token = await getTenantAccessToken(config.appId, config.appSecret);
        const fieldMap: Record<string, string> = config.fieldMapping
          ? JSON.parse(config.fieldMapping)
          : {};

        const records = await getAllBitableRecords(
          config.appToken,
          config.tableId,
          token
        );

        const allBrands = await db.query.brands.findMany();
        const brandMap = new Map<string, any>(allBrands.map((b) => [b.name, b]));

        let brandsMatched = 0;
        let brandsSkipped = 0;
        let snapshotsCreated = 0;

        for (const record of records) {
          try {
            const fields = record.fields;
            const brandName = extractFieldValue(fields, fieldMap["brandName"] || "品牌");
            if (!brandName) continue;

            const brand = brandMap.get(String(brandName));
            if (!brand) {
              brandsSkipped++;
              continue;
            }
            brandsMatched++;

            const spend = extractNumberValue(fields, fieldMap["spend"] || "消耗") || 0;
            const roi = extractNumberValue(fields, fieldMap["roi"] || "ROI") || 0;
            const gmv = extractNumberValue(fields, fieldMap["gmv"] || "GMV") || 0;

            let snapshotTime = new Date();
            const timeValue = extractFieldValue(fields, fieldMap["snapshotTime"] || "时间");
            if (timeValue) {
              snapshotTime = typeof timeValue === "number"
                ? new Date(timeValue)
                : new Date(String(timeValue));
              if (isNaN(snapshotTime.getTime())) snapshotTime = new Date();
            }

            await db.insert(dataSnapshots).values({
              brandId: brand.id,
              spend: String(spend),
              roi: String(roi),
              gmv: String(gmv),
              snapshotTime,
            });
            snapshotsCreated++;
          } catch {
            // 单条记录错误继续
          }
        }

        await db.update(syncLogs).set({
          status: "success",
          recordsProcessed: records.length,
          brandsMatched,
          message: `同步完成：${snapshotsCreated} 条快照，匹配 ${brandsMatched} 品牌，跳过 ${brandsSkipped} 条`,
          completedAt: new Date(),
        }).where(eq(syncLogs.id, logId));

        return {
          success: true,
          recordsProcessed: records.length,
          brandsMatched,
          brandsSkipped,
          snapshotsCreated,
        };
      } catch (error: any) {
        await db.update(syncLogs).set({
          status: "failed",
          errorDetail: error.message,
          completedAt: new Date(),
        }).where(eq(syncLogs.id, logId));
        return { success: false, error: error.message };
      }
    }),

  syncLogs: publicQuery
    .input(z.object({ limit: z.number().min(1).max(100).default(20) }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.syncLogs.findMany({
        orderBy: [desc(syncLogs.createdAt)],
        limit: input?.limit || 20,
      });
    }),

  diagnose: publicQuery
    .input(z.object({ configId: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const allBrands = await db.query.brands.findMany();
      const dashboardBrandNames = allBrands.map((b) => b.name);

      const config = await db.query.feishuConfig.findFirst({
        where: eq(feishuConfig.id, input.configId),
      });
      if (!config) {
        return { dashboardBrandNames, feishuBrandNames: [], matched: [], unmatched: [], error: "配置不存在" };
      }

      const fieldMap: Record<string, string> = config.fieldMapping
        ? JSON.parse(config.fieldMapping)
        : {};

      try {
        const token = await getTenantAccessToken(config.appId, config.appSecret);
        const records = await getAllBitableRecords(
          config.appToken,
          config.tableId,
          token
        );

        const brandField = fieldMap["brandName"] || "品牌";
        const feishuBrandNames: string[] = [];
        for (const r of records) {
          const name = extractFieldValue(r.fields, brandField);
          if (name && !feishuBrandNames.includes(String(name))) {
            feishuBrandNames.push(String(name));
          }
        }

        const matched = feishuBrandNames.filter((f) =>
          dashboardBrandNames.some((d) => d === f)
        );
        const unmatched = feishuBrandNames.filter(
          (f) => !dashboardBrandNames.some((d) => d === f)
        );
        const missingInFeishu = dashboardBrandNames.filter(
          (d) => !feishuBrandNames.some((f) => f === d)
        );

        // 检查时间列格式
        const timeField = fieldMap["snapshotTime"] || "时间";
        const timeAnalysis = {
          timeFieldName: timeField,
          totalRecords: records.length,
          hasTimeValue: 0,
          validDate: 0,
          invalidDate: 0,
          emptyDate: 0,
          dateDistribution: {} as Record<string, number>,
          sampleValid: [] as string[],
          sampleInvalid: [] as string[],
        };
        for (const r of records) {
          const tv = extractFieldValue(r.fields, timeField);
          if (tv === null || tv === undefined || tv === "") {
            timeAnalysis.emptyDate++;
            continue;
          }
          timeAnalysis.hasTimeValue++;
          const parsed = typeof tv === "number" ? new Date(tv) : new Date(String(tv));
          if (isNaN(parsed.getTime())) {
            timeAnalysis.invalidDate++;
            if (timeAnalysis.sampleInvalid.length < 3) timeAnalysis.sampleInvalid.push(String(tv));
          } else {
            timeAnalysis.validDate++;
            const dk = `${parsed.getUTCFullYear()}-${String(parsed.getUTCMonth()+1).padStart(2,"0")}-${String(parsed.getUTCDate()).padStart(2,"0")}`;
            timeAnalysis.dateDistribution[dk] = (timeAnalysis.dateDistribution[dk] || 0) + 1;
            if (timeAnalysis.sampleValid.length < 3) timeAnalysis.sampleValid.push(`${tv} → ${dk}`);
          }
        }

        return {
          dashboardBrandNames,
          feishuBrandNames,
          matched,
          unmatched,
          missingInFeishu,
          totalFeishuRecords: records.length,
          timeAnalysis,
        };
      } catch (error: any) {
        return { dashboardBrandNames, feishuBrandNames: [], matched: [], unmatched: [], error: error.message };
      }
    }),
});
