import { z } from "zod";
import { eq, desc, gte, lte, and } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { dataSnapshots } from "@db/schema";

export const snapshotRouter = createRouter({
  list: publicQuery
    .input(
      z.object({
        brandId: z.number().optional(),
        from: z.string().optional(),
        to: z.string().optional(),
        limit: z.number().min(1).max(1000).default(100),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];
      if (input.brandId) {
        conditions.push(eq(dataSnapshots.brandId, input.brandId));
      }
      if (input.from) {
        conditions.push(gte(dataSnapshots.snapshotTime, new Date(input.from)));
      }
      if (input.to) {
        conditions.push(lte(dataSnapshots.snapshotTime, new Date(input.to)));
      }

      return db.query.dataSnapshots.findMany({
        where: conditions.length > 0 ? and(...conditions) : undefined,
        orderBy: [desc(dataSnapshots.snapshotTime)],
        limit: input.limit,
        with: { brand: true },
      });
    }),

  latest: publicQuery
    .input(z.object({ brandId: z.number().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      if (input?.brandId) {
        return db.query.dataSnapshots.findFirst({
          where: eq(dataSnapshots.brandId, input.brandId),
          orderBy: [desc(dataSnapshots.snapshotTime)],
          with: { brand: true },
        });
      }
      const allSnapshots = await db.query.dataSnapshots.findMany({
        orderBy: [desc(dataSnapshots.snapshotTime)],
        with: { brand: true },
      });
      const latestByBrand = new Map();
      for (const s of allSnapshots) {
        if (!latestByBrand.has(s.brandId)) {
          latestByBrand.set(s.brandId, s);
        }
      }
      return Array.from(latestByBrand.values());
    }),

  submit: publicQuery
    .input(
      z.object({
        brandId: z.number(),
        spend: z.string(),
        roi: z.string().optional(),
        gmv: z.string(),
        snapshotTime: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(dataSnapshots).values({
        brandId: input.brandId,
        spend: input.spend,
        roi: input.roi || "0",
        gmv: input.gmv,
        snapshotTime: input.snapshotTime ? new Date(input.snapshotTime) : new Date(),
      });
      return { id: Number(result[0].insertId) };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(dataSnapshots).where(eq(dataSnapshots.id, input.id));
      return { success: true };
    }),
});
