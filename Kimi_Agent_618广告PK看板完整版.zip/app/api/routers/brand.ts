import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands } from "@db/schema";

export const brandRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db.query.brands.findMany({
      orderBy: [desc(brands.sortOrder)],
    });
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      return db.query.brands.findFirst({
        where: eq(brands.id, input.id),
      });
    }),

  create: publicQuery
    .input(
      z.object({
        name: z.string().min(1).max(100),
        accountId: z.string().min(1).max(100),
        logo: z.string().max(500).optional(),
        teamName: z.string().min(1).max(100),
        targetGmv: z.string().optional(),
        targetSpend: z.string().optional(),
        color: z.string().max(20).optional(),
        sortOrder: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(brands).values({
        name: input.name,
        accountId: input.accountId,
        logo: input.logo,
        teamName: input.teamName,
        targetGmv: input.targetGmv || "0",
        targetSpend: input.targetSpend || "0",
        color: input.color || "#3b82f6",
        sortOrder: input.sortOrder || 0,
      });
      return { id: Number(result[0].insertId) };
    }),

  update: publicQuery
    .input(
      z.object({
        id: z.number(),
        name: z.string().min(1).max(100).optional(),
        accountId: z.string().min(1).max(100).optional(),
        logo: z.string().max(500).optional(),
        teamName: z.string().min(1).max(100).optional(),
        targetGmv: z.string().optional(),
        targetSpend: z.string().optional(),
        color: z.string().max(20).optional(),
        sortOrder: z.number().optional(),
        isActive: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      await db.update(brands).set(data).where(eq(brands.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db.delete(brands).where(eq(brands.id, input.id));
      return { success: true };
    }),
});
