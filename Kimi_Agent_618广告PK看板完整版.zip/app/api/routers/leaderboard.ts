import { z } from "zod";
import { eq, desc, gte, lte, and } from "drizzle-orm";
import { createRouter, publicQuery } from "../middleware";
import { getDb } from "../queries/connection";
import { brands, dataSnapshots } from "@db/schema";

// 618 时间范围 UTC（2026年）
const START_618 = new Date(Date.UTC(2026, 4, 20, 0, 0, 0));
const END_618 = new Date(Date.UTC(2026, 6, 20, 23, 59, 59));

// 获取UTC日期键 YYYY-MM-DD
function utcDateKey(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
}

// 按天取最后一条（当天最新时间戳）的消耗和GMV，跨天累加
function aggregateDailyLast(
  snapshots: Array<{ spend: string | null; gmv: string | null; snapshotTime: Date }>
): { totalSpend: number; totalGmv: number; roi: string; days: number } {
  const daily = new Map<string, { spend: number; gmv: number }>();

  for (const s of snapshots) {
    const dk = utcDateKey(s.snapshotTime);
    const sp = parseFloat(s.spend || "0");
    const gv = parseFloat(s.gmv || "0");
    // 同一天的记录，后面覆盖前面（因为快照按时间排序后遍历，后面的时间更晚）
    daily.set(dk, { spend: sp, gmv: gv });
  }

  let ts = 0, tg = 0;
  for (const d of daily.values()) { ts += d.spend; tg += d.gmv; }
  return { totalSpend: ts, totalGmv: tg, roi: ts > 0 ? (tg / ts).toFixed(2) : "0.00", days: daily.size };
}

export const leaderboardRouter = createRouter({
  // 排行榜：每日/618总/指定日期
  get: publicQuery
    .input(
      z.object({
        mode: z.enum(["daily", "total618"]).default("daily"),
        sortBy: z.enum(["gmv", "spend", "roi"]).default("gmv"),
        date: z.string().optional(), // YYYY-MM-DD
      }).optional()
    )
    .query(async ({ input }) => {
      const db = getDb();
      const mode = input?.mode || "daily";
      const sortBy = input?.sortBy || "gmv";

      const allBrands = await db.query.brands.findMany({
        where: eq(brands.isActive, 1),
        orderBy: [desc(brands.sortOrder)],
      });

      const results = [];

      for (const brand of allBrands) {
        let snapshot: any = null;
        let dataSource = "";

        if (mode === "total618") {
          // 618总排名：5.20-6.20 每天最大累加
          const snaps = await db.query.dataSnapshots.findMany({
            where: and(
              eq(dataSnapshots.brandId, brand.id),
              gte(dataSnapshots.snapshotTime, START_618),
              lte(dataSnapshots.snapshotTime, END_618)
            ),
            orderBy: [dataSnapshots.snapshotTime], // 升序，aggregateDailyLast 取每天最后一条
          });
          if (snaps.length > 0) {
            const agg = aggregateDailyLast(snaps);
            snapshot = {
              spend: agg.totalSpend.toFixed(2),
              roi: agg.roi,
              gmv: agg.totalGmv.toFixed(2),
              snapshotTime: snaps[0].snapshotTime,
            };
            dataSource = `${agg.days}天累加`;
          }
        } else {
          // 每日排名：只取当天的最新一条快照，没有当天数据就显示0
          const todayKey = utcDateKey(new Date());
          const targetDate = input?.date || todayKey; // 指定日期或今天
          const [year, month, day] = targetDate.split("-").map(Number);
          const dayStart = new Date(Date.UTC(year, month - 1, day, 0, 0, 0));
          const dayEnd = new Date(Date.UTC(year, month - 1, day, 23, 59, 59));

          snapshot = await db.query.dataSnapshots.findFirst({
            where: and(
              eq(dataSnapshots.brandId, brand.id),
              gte(dataSnapshots.snapshotTime, dayStart),
              lte(dataSnapshots.snapshotTime, dayEnd)
            ),
            orderBy: [desc(dataSnapshots.snapshotTime)],
          });
          if (snapshot) {
            dataSource = targetDate === todayKey ? "今日" : targetDate;
          }
        }

        if (snapshot) {
          const progress = parseFloat(brand.targetGmv || "0") > 0
            ? Math.min((parseFloat(snapshot.gmv || "0") / parseFloat(brand.targetGmv)) * 100, 100)
            : 0;

          results.push({
            brandId: brand.id,
            brandName: brand.name,
            teamName: brand.teamName,
            color: brand.color,
            targetGmv: brand.targetGmv,
            targetSpend: brand.targetSpend,
            spend: snapshot.spend,
            roi: snapshot.roi,
            gmv: snapshot.gmv,
            progress: progress.toFixed(2),
            lastUpdated: snapshot.snapshotTime,
            dataSource,
          });
        } else {
          results.push({
            brandId: brand.id,
            brandName: brand.name,
            teamName: brand.teamName,
            color: brand.color,
            targetGmv: brand.targetGmv,
            targetSpend: brand.targetSpend,
            spend: "0", roi: "0", gmv: "0",
            progress: "0",
            lastUpdated: null,
            dataSource: "",
          });
        }
      }

      const field = { gmv: "gmv", spend: "spend", roi: "roi" }[sortBy] || "gmv";
      results.sort((a: any, b: any) => parseFloat(b[field] || "0") - parseFloat(a[field] || "0"));

      return results.map((item, index) => ({ ...item, rank: index + 1 }));
    }),

  // 趋势
  trend: publicQuery
    .input(z.object({ brandId: z.number(), hours: z.number().min(1).max(168).default(24) }))
    .query(async ({ input }) => {
      const db = getDb();
      const from = new Date();
      from.setHours(from.getHours() - input.hours);
      return db.query.dataSnapshots.findMany({
        where: and(eq(dataSnapshots.brandId, input.brandId), gte(dataSnapshots.snapshotTime, from)),
        orderBy: [desc(dataSnapshots.snapshotTime)],
      });
    }),

  // 每日历史
  dailyHistory: publicQuery
    .input(z.object({ brandId: z.number().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      let snapshots;
      const baseWhere = and(
        gte(dataSnapshots.snapshotTime, START_618),
        lte(dataSnapshots.snapshotTime, END_618)
      );
      if (input?.brandId) {
        snapshots = await db.query.dataSnapshots.findMany({
          where: and(eq(dataSnapshots.brandId, input.brandId), baseWhere),
          orderBy: [desc(dataSnapshots.snapshotTime)],
          with: { brand: true },
        });
      } else {
        snapshots = await db.query.dataSnapshots.findMany({
          where: baseWhere,
          orderBy: [desc(dataSnapshots.snapshotTime)],
          with: { brand: true },
        });
      }

      // 按天+品牌分组，取每天最后一条（快照按时间倒序，先遇到的是当天最新的）
      const daily = new Map<string, { date: string; brandId: number; brandName: string; gmv: number }>();
      for (const s of snapshots) {
        const dk = utcDateKey(s.snapshotTime);
        const bid = s.brandId;
        const key = `${bid}_${dk}`;
        const gv = parseFloat(s.gmv || "0");
        const bn = (s as any).brand?.name || String(bid);
        // 第一次遇到的每个key就是当天该品牌最新的一条，后面覆盖即可
        daily.set(key, { date: dk, brandId: bid, brandName: bn, gmv: gv });
      }
      return Array.from(daily.values()).sort((a, b) => b.date.localeCompare(a.date) || b.gmv - a.gmv);
    }),

  // 汇总统计
  summary: publicQuery
    .input(z.object({ mode: z.enum(["daily", "total618"]).default("daily"), date: z.string().optional() }).optional())
    .query(async ({ input }) => {
      const db = getDb();
      const mode = input?.mode || "daily";
      const allBrands = await db.query.brands.findMany({ where: eq(brands.isActive, 1) });

      let totalSpend = 0, totalGmv = 0, activeBrands = 0;

      if (mode === "daily") {
        const todayStart = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate(), 0, 0, 0));
        const todayEnd = new Date(Date.UTC(new Date().getUTCFullYear(), new Date().getUTCMonth(), new Date().getUTCDate(), 23, 59, 59));
        for (const brand of allBrands) {
          const snap = await db.query.dataSnapshots.findFirst({
            where: and(
              eq(dataSnapshots.brandId, brand.id),
              gte(dataSnapshots.snapshotTime, todayStart),
              lte(dataSnapshots.snapshotTime, todayEnd)
            ),
            orderBy: [desc(dataSnapshots.snapshotTime)],
          });
          if (snap) {
            totalSpend += parseFloat(snap.spend || "0");
            totalGmv += parseFloat(snap.gmv || "0");
            if (parseFloat(snap.gmv || "0") > 0) activeBrands++;
          }
        }
      } else {
        for (const brand of allBrands) {
          const snaps = await db.query.dataSnapshots.findMany({
            where: and(
              eq(dataSnapshots.brandId, brand.id),
              gte(dataSnapshots.snapshotTime, START_618),
              lte(dataSnapshots.snapshotTime, END_618)
            ),
            orderBy: [dataSnapshots.snapshotTime], // 升序，aggregateDailyLast 取每天最后一条
          });
          if (snaps.length > 0) {
            const agg = aggregateDailyLast(snaps);
            totalSpend += agg.totalSpend;
            totalGmv += agg.totalGmv;
            if (agg.totalGmv > 0) activeBrands++;
          }
        }
      }

      const totalTarget = allBrands.reduce((s, b) => s + parseFloat(b.targetGmv || "0"), 0);
      const totalSpendTarget = allBrands.reduce((s, b) => s + parseFloat(b.targetSpend || "0"), 0);

      return {
        totalBrands: allBrands.length,
        activeBrands,
        totalSpend: totalSpend.toFixed(2),
        totalGmv: totalGmv.toFixed(2),
        totalTarget: totalTarget.toFixed(2),
        totalSpendTarget: totalSpendTarget.toFixed(2),
        overallRoi: totalSpend > 0 ? (totalGmv / totalSpend).toFixed(2) : "0",
        overallProgress: totalTarget > 0 ? ((totalGmv / totalTarget) * 100).toFixed(2) : "0",
      };
    }),

  // 诊断 - 累计=每天最后一条数据累加
  snapshotStats: publicQuery.query(async () => {
    const db = getDb();
    const allBrands = await db.query.brands.findMany();
    const stats = [];
    for (const brand of allBrands) {
      const snapshots = await db.query.dataSnapshots.findMany({
        where: eq(dataSnapshots.brandId, brand.id),
        orderBy: [desc(dataSnapshots.snapshotTime)],
      });
      if (snapshots.length > 0) {
        const latest = snapshots[0];
        // 按天分组，每天取最后一条，跨天累加
        const dailyLast = new Map<string, { spend: number; gmv: number }>();
        for (const s of snapshots) {
          const dk = utcDateKey(s.snapshotTime);
          // 因为是按时间倒序，第一次遇到的每个日期就是该天最新
          if (!dailyLast.has(dk)) {
            dailyLast.set(dk, {
              spend: parseFloat(s.spend || "0"),
              gmv: parseFloat(s.gmv || "0"),
            });
          }
        }
        let ts = 0, tg = 0;
        for (const d of dailyLast.values()) { ts += d.spend; tg += d.gmv; }
        stats.push({
          brandId: brand.id, brandName: brand.name, teamName: brand.teamName,
          snapshotCount: snapshots.length,
          latestSpend: String(latest.spend ?? "0"), latestRoi: String(latest.roi ?? "0"), latestGmv: String(latest.gmv ?? "0"),
          latestTime: latest.snapshotTime, totalSpend: ts.toFixed(2), totalGmv: tg.toFixed(2),
        });
      } else {
        stats.push({
          brandId: brand.id, brandName: brand.name, teamName: brand.teamName,
          snapshotCount: 0, latestSpend: null, latestRoi: null, latestGmv: null,
          latestTime: null, totalSpend: "0", totalGmv: "0",
        });
      }
    }
    return stats;
  }),
});
