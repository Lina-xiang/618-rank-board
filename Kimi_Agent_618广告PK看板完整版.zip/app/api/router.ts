import { createRouter, publicQuery } from "./middleware";
import { brandRouter } from "./routers/brand";
import { snapshotRouter } from "./routers/snapshot";
import { leaderboardRouter } from "./routers/leaderboard";
import { feishuRouter } from "./routers/feishu";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  brand: brandRouter,
  snapshot: snapshotRouter,
  leaderboard: leaderboardRouter,
  feishu: feishuRouter,
});

export type AppRouter = typeof appRouter;
