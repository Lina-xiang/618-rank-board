// 飞书 API 客户端

const FEISHU_API_BASE = "https://open.feishu.cn/open-apis";

interface TokenResponse {
  code: number;
  msg: string;
  tenant_access_token?: string;
  expire?: number;
}

interface FeishuRecord {
  record_id: string;
  fields: Record<string, any>;
  created_time?: number;
  last_modified_time?: number;
}

interface RecordsResponse {
  code: number;
  msg: string;
  data?: {
    items?: FeishuRecord[];
    total?: number;
    has_more?: boolean;
    page_token?: string;
  };
}

// 获取 tenant_access_token
export async function getTenantAccessToken(appId: string, appSecret: string): Promise<string> {
  const response = await fetch(`${FEISHU_API_BASE}/auth/v3/tenant_access_token/internal`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
  });

  const data = await response.json() as TokenResponse;
  if (data.code !== 0 || !data.tenant_access_token) {
    throw new Error(`获取 tenant_access_token 失败: ${data.msg}`);
  }
  return data.tenant_access_token;
}

// 获取多维表格记录列表
export async function getBitableRecords(
  appToken: string,
  tableId: string,
  tenantToken: string,
  options?: { pageSize?: number; pageToken?: string; filter?: string }
): Promise<{ records: FeishuRecord[]; hasMore: boolean; pageToken?: string; total: number }> {
  const params = new URLSearchParams();
  params.append("page_size", String(options?.pageSize || 500));
  if (options?.pageToken) params.append("page_token", options.pageToken);
  if (options?.filter) params.append("filter", options.filter);

  const url = `${FEISHU_API_BASE}/bitable/v1/apps/${appToken}/tables/${tableId}/records?${params.toString()}`;

  const response = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${tenantToken}`,
      "Content-Type": "application/json",
    },
  });

  const data = await response.json() as RecordsResponse;
  if (data.code !== 0) {
    throw new Error(`获取多维表格记录失败: ${data.msg}`);
  }

  return {
    records: data.data?.items || [],
    hasMore: data.data?.has_more || false,
    pageToken: data.data?.page_token,
    total: data.data?.total || 0,
  };
}

// 获取所有记录（自动分页）
export async function getAllBitableRecords(
  appToken: string,
  tableId: string,
  tenantToken: string,
  options?: { filter?: string }
): Promise<FeishuRecord[]> {
  const allRecords: FeishuRecord[] = [];
  let pageToken: string | undefined;

  do {
    const result = await getBitableRecords(appToken, tableId, tenantToken, {
      pageSize: 500,
      pageToken,
      filter: options?.filter,
    });
    allRecords.push(...result.records);
    pageToken = result.pageToken;
  } while (pageToken);

  return allRecords;
}

// 字段值解析工具
export function extractFieldValue(fields: Record<string, any>, fieldName: string): any {
  const value = fields[fieldName];
  if (value === undefined || value === null) return null;

  // 处理飞书多维表格的各种字段类型
  if (typeof value === "string") return value;
  if (typeof value === "number") return value;
  if (typeof value === "boolean") return value;

  // 处理数组类型（如多选、人员等）
  if (Array.isArray(value)) {
    if (value.length === 0) return null;
    if (typeof value[0] === "string") return value[0];
    if (value[0]?.text) return value[0].text;
    return value[0];
  }

  // 处理对象类型（如数字字段有时返回对象）
  if (typeof value === "object") {
    if (value.value !== undefined) return value.value;
    if (value.text) return value.text;
  }

  return value;
}

// 解析数字字段值
export function extractNumberValue(fields: Record<string, any>, fieldName: string): number | null {
  const value = extractFieldValue(fields, fieldName);
  if (value === null || value === undefined) return null;
  const num = parseFloat(String(value).replace(/,/g, ""));
  return isNaN(num) ? null : num;
}
