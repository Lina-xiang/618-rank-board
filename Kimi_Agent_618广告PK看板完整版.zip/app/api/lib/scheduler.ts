// 定时任务调度器 - 每小时第10分钟自动同步飞书数据

import { getDb } from "../queries/connection";
import { feishuConfig, syncLogs, dataSnapshots } from "@db/schema";
import { eq, and, desc } from "drizzle-orm";
import {
  getTenantAccessToken,
  getAllBitableRecords,
  extractFieldValue,
  extractNumberValue,
} from "./feishu";

let schedulerInitialized = false;

/**
 * 执行飞书数据同步（内部直接调用，不依赖HTTP路由）
 */
export async function runFeishuSync(): Promise<{
  success: boolean;
  message: string;
  snapshotsCreated?: number;
}> {
  const db = getDb();

  const config = await db.query.feishuConfig.findFirst({
    where: eq(feishuConfig.isActive, 1),
  });

  if (!config) {
    return { success: false, message: "没有启用的飞书配置，跳过同步" };
  }

  // 检查最近5分钟内是否已同步过，避免重复
  const recentLogs = await db.query.syncLogs.findMany({
    where: eq(syncLogs.status, "success"),
    orderBy: [desc(syncLogs.completedAt)],
    limit: 1,
  });

  if (recentLogs.length > 0 && recentLogs[0].completedAt) {
    const lastSync = new Date(recentLogs[0].completedAt);
    const now = new Date();
    const diffMinutes = (now.getTime() - lastSync.getTime()) / 1000 / 60;
    if (diffMinutes < 5) {
      return { success: false, message: `5分钟内已同步过（${diffMinutes.toFixed(1)}分钟前），跳过` };
    }
  }

  // 创建同步日志
  const logResult = await db.insert(syncLogs).values({
    configId: config.id,
    status: "running",
    startedAt: new Date(),
  });
  const logId = Number(logResult[0].insertId);

  try {
    const token = await getTenantAccessToken(config.appId, config.appSecret);
    const fieldMap: Record<string, string> = config.fieldMapping
      ? JSON.parse(config.fieldMapping)
      : {};

    const records = await getAllBitableRecords(
      config.appToken,
      config.tableId,
      token
    );

    const allBrands = await db.query.brands.findMany();
    const brandMap = new Map<string, any>(allBrands.map((b) => [b.name, b]));

    let brandsMatched = 0;
    let brandsSkipped = 0;
    let snapshotsCreated = 0;

    for (const record of records) {
      try {
        const fields = record.fields;
        const brandName = extractFieldValue(fields, fieldMap["brandName"] || "品牌");
        if (!brandName) continue;

        // 只匹配已有品牌，不匹配则跳过（不创建新品牌）
        const brand = brandMap.get(String(brandName));
        if (!brand) {
          brandsSkipped++;
          continue;
        }
        brandsMatched++;

        const spend = extractNumberValue(fields, fieldMap["spend"] || "消耗") || 0;
        const roi = extractNumberValue(fields, fieldMap["roi"] || "ROI") || 0;
        const gmv = extractNumberValue(fields, fieldMap["gmv"] || "GMV") || 0;

        let snapshotTime = new Date();
        const timeValue = extractFieldValue(fields, fieldMap["snapshotTime"] || "时间");
        if (timeValue) {
          snapshotTime = typeof timeValue === "number"
            ? new Date(timeValue)
            : new Date(String(timeValue));
          if (isNaN(snapshotTime.getTime())) snapshotTime = new Date();
        }

        await db.insert(dataSnapshots).values({
          brandId: brand.id,
          spend: String(spend),
          roi: String(roi),
          gmv: String(gmv),
          snapshotTime,
        });
        snapshotsCreated++;
      } catch {
        // 单条记录错误继续处理下一条
      }
    }

    await db.update(syncLogs).set({
      status: "success",
      recordsProcessed: records.length,
      brandsMatched,
      message: `自动同步：${snapshotsCreated} 条快照，匹配 ${brandsMatched} 品牌，跳过 ${brandsSkipped} 条`,
      completedAt: new Date(),
    }).where(eq(syncLogs.id, logId));

    return {
      success: true,
      message: `同步完成：${snapshotsCreated} 条快照`,
      snapshotsCreated,
    };
  } catch (error: any) {
    await db.update(syncLogs).set({
      status: "failed",
      errorDetail: error.message,
      completedAt: new Date(),
    }).where(eq(syncLogs.id, logId));

    return { success: false, message: error.message };
  }
}

/**
 * 计算距离下一个目标分钟数的毫秒数
 * @param targetMinute 目标分钟数（0-59）
 */
function getMsUntilNextMinute(targetMinute: number): number {
  const now = new Date();
  const target = new Date(now);
  target.setMinutes(targetMinute, 0, 0);

  if (target <= now) {
    // 目标时间已过，设为下一小时
    target.setHours(target.getHours() + 1);
  }

  return target.getTime() - now.getTime();
}

/**
 * 启动定时同步调度器
 * 每小时第10分钟自动执行
 */
export function startSyncScheduler(): void {
  if (schedulerInitialized) return;
  schedulerInitialized = true;

  const TARGET_MINUTE = 10;

  const scheduleNext = () => {
    const delay = getMsUntilNextMinute(TARGET_MINUTE);
    console.log(`[Scheduler] 下次同步将在 ${TARGET_MINUTE} 分执行，等待 ${Math.round(delay / 1000 / 60)} 分钟`);

    setTimeout(async () => {
      console.log(`[Scheduler] === 自动同步开始 ${new Date().toLocaleString()} ===`);
      const result = await runFeishuSync();
      console.log(`[Scheduler] === 自动同步结束: ${result.message} ===`);
      // 安排下一次
      scheduleNext();
    }, delay);
  };

  // 启动
  scheduleNext();
  console.log(`[Scheduler] 定时同步已启动，每小时第 ${TARGET_MINUTE} 分钟自动同步飞书数据`);
}
