import "dotenv/config";
import { getDb } from "../api/queries/connection";
import { dataSnapshots } from "./schema";
import { eq, desc } from "drizzle-orm";

async function main() {
  const db = getDb();
  
  const brandId = 43163; // 黑金帮
  const snapshots = await db.query.dataSnapshots.findMany({
    where: eq(dataSnapshots.brandId, brandId),
    orderBy: [desc(dataSnapshots.snapshotTime)],
  });
  
  console.log("Snapshot count:", snapshots.length);
  
  if (snapshots.length > 0) {
    const latest = snapshots[0];
    console.log("--- Latest snapshot raw ---");
    console.log("Full object:", JSON.stringify(latest, null, 2));
    console.log("spend:", JSON.stringify(latest.spend), "type:", typeof latest.spend);
    console.log("roi:", JSON.stringify(latest.roi), "type:", typeof latest.roi);
    console.log("gmv:", JSON.stringify(latest.gmv), "type:", typeof latest.gmv);
    console.log("brandId:", JSON.stringify(latest.brandId), "type:", typeof latest.brandId);
    console.log("snapshotTime:", JSON.stringify(latest.snapshotTime), "type:", typeof latest.snapshotTime);
    
    // 检查 null/undefined
    console.log("spend === null:", latest.spend === null);
    console.log("spend === undefined:", latest.spend === undefined);
    console.log("spend == null:", latest.spend == null);
    
    // 模拟 snapshotStats 的返回
    const ts = snapshots.reduce((s, sn) => s + parseFloat(sn.spend || "0"), 0);
    const tg = snapshots.reduce((s, sn) => s + parseFloat(sn.gmv || "0"), 0);
    const result = {
      brandId,
      snapshotCount: snapshots.length,
      latestSpend: latest.spend,
      latestRoi: latest.roi,
      latestGmv: latest.gmv,
      latestTime: latest.snapshotTime,
      totalSpend: ts.toFixed(2),
      totalGmv: tg.toFixed(2),
    };
    console.log("\n--- Simulated API result ---");
    console.log(JSON.stringify(result, null, 2));
  }
}

main().catch(e => { console.error(e); process.exit(1); });
