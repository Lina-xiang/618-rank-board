require("dotenv").config();
const { drizzle } = require("drizzle-orm/mysql2");
const mysql = require("mysql2/promise");
const schema = require("./schema");

async function main() {
  const url = new URL(process.env.DATABASE_URL);
  const pool = mysql.createPool({
    host: url.hostname, port: parseInt(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.slice(1),
    ssl: { rejectUnauthorized: false },
  });
  const db = drizzle(pool, { schema, mode: "default" });

  // 查询黑金帮 (brandId=43163) 的快照
  const brandId = 43163;
  console.log("=== Drizzle query result for brandId=" + brandId + " ===");
  
  const snapshots = await db.query.dataSnapshots.findMany({
    where: (0, require("drizzle-orm").eq)(schema.dataSnapshots.brandId, brandId),
    orderBy: [(0, require("drizzle-orm").desc)(schema.dataSnapshots.snapshotTime)],
  });
  
  console.log("Snapshot count:", snapshots.length);
  
  if (snapshots.length > 0) {
    const latest = snapshots[0];
    console.log("\n--- Latest snapshot (raw) ---");
    console.log("Keys:", Object.keys(latest).join(", "));
    console.log("spend:", JSON.stringify(latest.spend), "type:", typeof latest.spend);
    console.log("roi:", JSON.stringify(latest.roi), "type:", typeof latest.roi);
    console.log("gmv:", JSON.stringify(latest.gmv), "type:", typeof latest.gmv);
    console.log("snapshotTime:", latest.snapshotTime, "type:", typeof latest.snapshotTime);
    console.log("brandId:", latest.brandId, "type:", typeof latest.brandId);
    
    // 检查是否有 snake_case 的键
    console.log("\n--- All enumerable properties ---");
    for (const key of Object.keys(latest)) {
      console.log("  " + key + ":", JSON.stringify(latest[key]), "type:", typeof latest[key]);
    }
    
    // 测试累计
    const ts = snapshots.reduce((s, sn) => s + parseFloat(sn.spend || "0"), 0);
    const tg = snapshots.reduce((s, sn) => s + parseFloat(sn.gmv || "0"), 0);
    console.log("\n--- Aggregation ---");
    console.log("Total spend:", ts);
    console.log("Total gmv:", tg);
  }
  
  await pool.end();
}

main().catch(function(e) { console.error(e); process.exit(1); });
