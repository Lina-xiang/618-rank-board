import {
  mysqlTable,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  decimal,
  int,
  mysqlEnum,
} from "drizzle-orm/mysql-core";

// 品牌表
export const brands = mysqlTable("brands", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  accountId: varchar("account_id", { length: 100 }).notNull(),
  logo: varchar("logo", { length: 500 }),
  teamName: varchar("team_name", { length: 100 }).notNull(),
  targetGmv: decimal("target_gmv", { precision: 15, scale: 2 }).notNull().default("0"),
  targetSpend: decimal("target_spend", { precision: 15, scale: 2 }).notNull().default("0"),
  color: varchar("color", { length: 20 }).default("#3b82f6"),
  sortOrder: int("sort_order").default(0),
  isActive: int("is_active").default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

// 千川数据快照表 - 核心指标：消耗 / ROI / GMV
export const dataSnapshots = mysqlTable("data_snapshots", {
  id: serial("id").primaryKey(),
  brandId: bigint("brand_id", { mode: "number", unsigned: true }).notNull(),
  spend: decimal("spend", { precision: 15, scale: 2 }).notNull().default("0"),
  roi: decimal("roi", { precision: 8, scale: 2 }).default("0"),
  gmv: decimal("gmv", { precision: 15, scale: 2 }).notNull().default("0"),
  snapshotTime: timestamp("snapshot_time").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// 飞书配置表
export const feishuConfig = mysqlTable("feishu_config", {
  id: serial("id").primaryKey(),
  appId: varchar("app_id", { length: 100 }).notNull(),
  appSecret: varchar("app_secret", { length: 200 }).notNull(),
  appToken: varchar("app_token", { length: 100 }).notNull(),
  tableId: varchar("table_id", { length: 100 }).notNull(),
  // 字段映射：JSON字符串 {"brandName":"品牌","teamName":"团队","spend":"消耗","roi":"ROI","gmv":"GMV","snapshotTime":"时间"}
  fieldMapping: text("field_mapping"),
  isActive: int("is_active").default(1),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow().onUpdateNow(),
});

// 数据同步日志
export const syncLogs = mysqlTable("sync_logs", {
  id: serial("id").primaryKey(),
  configId: bigint("config_id", { mode: "number", unsigned: true }),
  status: mysqlEnum("status", ["pending", "running", "success", "failed"]).default("pending"),
  recordsProcessed: int("records_processed").default(0),
  brandsMatched: int("brands_matched").default(0),
  brandsCreated: int("brands_created").default(0),
  message: text("message"),
  errorDetail: text("error_detail"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
