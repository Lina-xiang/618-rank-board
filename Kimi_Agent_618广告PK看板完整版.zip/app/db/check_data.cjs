require("dotenv").config();
const mysql = require("mysql2/promise");
async function main() {
  const url = new URL(process.env.DATABASE_URL);
  const conn = await mysql.createConnection({
    host: url.hostname, port: parseInt(url.port),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.slice(1),
    ssl: { rejectUnauthorized: false },
    connectTimeout: 5000,
  });

  // 先看看有哪些 brand_id
  const [brandIds] = await conn.execute("SELECT DISTINCT brand_id FROM data_snapshots");
  console.log("Brand IDs in snapshots:", brandIds.map(function(r) { return r.brand_id; }).join(", "));
  
  // 看看 brands 表
  const [brands] = await conn.execute("SELECT id, name FROM brands ORDER BY id");
  console.log("\nBrands:");
  brands.forEach(function(b) { console.log("  [" + b.id + "] " + b.name); });
  
  // 查第一个有数据的 brand
  if (brandIds.length > 0) {
    var firstBrandId = brandIds[0].brand_id;
    console.log("\nFirst brandId with data:", firstBrandId);
    const [row] = await conn.execute(
      "SELECT brand_id, spend, roi, gmv, snapshot_time FROM data_snapshots WHERE brand_id = ? ORDER BY snapshot_time DESC LIMIT 1",
      [firstBrandId]
    );
    if (row[0]) {
      console.log("spend:", JSON.stringify(row[0].spend), "type:", typeof row[0].spend);
      console.log("roi:", JSON.stringify(row[0].roi), "type:", typeof row[0].roi);
      console.log("gmv:", JSON.stringify(row[0].gmv), "type:", typeof row[0].gmv);
      console.log("time:", row[0].snapshot_time);
    }
  }

  const [cols] = await conn.execute("DESCRIBE data_snapshots");
  cols.forEach(function(c) {
    console.log(c.Field + ":" + c.Type + " null=" + c.Null);
  });

  await conn.end();
}
main().catch(function(e) { console.error(e.message); process.exit(1); });
