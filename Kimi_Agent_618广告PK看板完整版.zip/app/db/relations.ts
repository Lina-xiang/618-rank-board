import { relations } from "drizzle-orm";
import { brands, dataSnapshots, feishuConfig, syncLogs } from "./schema";

export const brandRelations = relations(brands, ({ many }) => ({
  snapshots: many(dataSnapshots),
}));

export const snapshotRelations = relations(dataSnapshots, ({ one }) => ({
  brand: one(brands, {
    fields: [dataSnapshots.brandId],
    references: [brands.id],
  }),
}));

export const feishuConfigRelations = relations(feishuConfig, ({ many }) => ({
  syncLogs: many(syncLogs),
}));

export const syncLogRelations = relations(syncLogs, ({ one }) => ({
  config: one(feishuConfig, {
    fields: [syncLogs.configId],
    references: [feishuConfig.id],
  }),
}));
