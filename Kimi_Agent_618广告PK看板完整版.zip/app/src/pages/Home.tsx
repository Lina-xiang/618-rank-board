import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { SummaryCards } from "@/components/dashboard/SummaryCards";
import { Leaderboard } from "@/components/dashboard/Leaderboard";
import { TrendChart } from "@/components/dashboard/TrendChart";
import { BrandManager } from "@/components/dashboard/BrandManager";
import { FeishuConfig } from "@/components/dashboard/FeishuConfig";
import { FeishuGuide } from "@/components/dashboard/FeishuGuide";
import { trpc } from "@/providers/trpc";
import {
  Trophy, TrendingUp, Settings, Link2, RefreshCw,
  Activity, BarChart3, Calendar, Award, FileSpreadsheet, History,
} from "lucide-react";

const DATE_OPTIONS = (() => {
  const dates: string[] = [];
  const s = new Date("2026-05-20T00:00:00Z"), e = new Date("2026-06-20T00:00:00Z");
  for (let d = new Date(s); d <= e; d.setUTCDate(d.getUTCDate() + 1)) dates.push(d.toISOString().slice(0, 10));
  return dates;
})();

export default function Home() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [rankMode, setRankMode] = useState<"daily" | "total618">("daily");
  const [sortBy, setSortBy] = useState("gmv");
  const [queryDate, setQueryDate] = useState<string>("");
  const [lastRefresh, setLastRefresh] = useState(new Date());

  const utils = trpc.useUtils();

  const { data: summaryData, isLoading: summaryLoading } =
    trpc.leaderboard.summary.useQuery({ mode: rankMode });

  const { data: leaderboardData, isLoading: leaderboardLoading } =
    trpc.leaderboard.get.useQuery({ mode: rankMode, sortBy: sortBy as any });

  const { data: brandList, isLoading: brandLoading } = trpc.brand.list.useQuery();

  const { data: dailyHistory } = trpc.leaderboard.dailyHistory.useQuery({});

  const createBrand = trpc.brand.create.useMutation({
    onSuccess: () => { toast.success("品牌添加成功"); utils.brand.list.invalidate(); },
    onError: (err: any) => toast.error(err.message),
  });
  const updateBrand = trpc.brand.update.useMutation({
    onSuccess: () => { toast.success("品牌更新成功"); utils.brand.list.invalidate(); },
    onError: (err: any) => toast.error(err.message),
  });
  const deleteBrand = trpc.brand.delete.useMutation({
    onSuccess: () => { toast.success("品牌删除成功"); utils.brand.list.invalidate(); },
    onError: (err: any) => toast.error(err.message),
  });

  const handleRefresh = () => {
    utils.leaderboard.summary.invalidate();
    utils.leaderboard.get.invalidate();
    utils.leaderboard.snapshotStats.invalidate();
    utils.leaderboard.dailyHistory.invalidate();
    setLastRefresh(new Date());
    toast.success("数据已刷新");
  };

  // 判断API是否返回了有效数据（有非0的gmv）
  const hasRealData = leaderboardData && (leaderboardData as any[]).some((d: any) => parseFloat(d.gmv || "0") > 0);
  const displayLeaderboard = hasRealData ? leaderboardData : [];
  const displaySummary = summaryData;
  const displayBrands = (brandList || []) as any;

  const rankTitle = queryDate
    ? `${queryDate} 排名`
    : rankMode === "daily"
      ? "今日实时排名"
      : "618总排名（5.20-6.20）";

  const badgeLabel = queryDate ? "指定日期" : rankMode === "daily" ? "每小时10分自动同步" : "5.20-6.20累计";

  return (
    <div className="min-h-screen bg-gray-50">
      <Toaster />

      <header className="bg-white border-b sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-red-500 to-pink-600 rounded-lg flex items-center justify-center">
                <Trophy className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-lg font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">星罗618品牌PK看板</h1>
                <p className="text-xs text-gray-500">千川数据 · 飞书多维表格 · GMV追踪</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="bg-emerald-50 text-emerald-600 border-emerald-200"><Activity className="w-3 h-3 mr-1" />GMV</Badge>
              <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200"><FileSpreadsheet className="w-3 h-3 mr-1" />飞书</Badge>
              <span className="text-xs text-gray-400 hidden sm:inline">更新于 {lastRefresh.toLocaleTimeString()}</span>
              <Button variant="outline" size="sm" className="h-8" onClick={handleRefresh}>
                <RefreshCw className="w-4 h-4 mr-1" />刷新
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full max-w-2xl grid-cols-6">
            <TabsTrigger value="dashboard" className="gap-1"><BarChart3 className="w-4 h-4" /><span className="hidden sm:inline">数据看板</span></TabsTrigger>
            <TabsTrigger value="history" className="gap-1"><History className="w-4 h-4" /><span className="hidden sm:inline">每日历史</span></TabsTrigger>
            <TabsTrigger value="trends" className="gap-1"><TrendingUp className="w-4 h-4" /><span className="hidden sm:inline">趋势分析</span></TabsTrigger>
            <TabsTrigger value="feishu" className="gap-1"><Link2 className="w-4 h-4" /><span className="hidden sm:inline">飞书配置</span></TabsTrigger>
            <TabsTrigger value="brands" className="gap-1"><Settings className="w-4 h-4" /><span className="hidden sm:inline">品牌管理</span></TabsTrigger>
            <TabsTrigger value="guide" className="gap-1"><FileSpreadsheet className="w-4 h-4" /><span className="hidden sm:inline">配置指南</span></TabsTrigger>
          </TabsList>

          {/* 数据看板 */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-2 bg-white rounded-lg p-1 shadow-sm border">
                  <Button variant={rankMode === "daily" && !queryDate ? "default" : "ghost"} size="sm" className="h-8 gap-1"
                    onClick={() => { setRankMode("daily"); setQueryDate(""); }}>
                    <Calendar className="w-4 h-4" />今日排名
                  </Button>
                  <Button variant={rankMode === "total618" && !queryDate ? "default" : "ghost"} size="sm" className="h-8 gap-1"
                    onClick={() => { setRankMode("total618"); setQueryDate(""); }}>
                    <Award className="w-4 h-4" />618总排名
                  </Button>
                </div>
                <div className="flex items-center gap-2 bg-white rounded-lg px-3 py-1 shadow-sm border">
                  <span className="text-xs text-gray-500 whitespace-nowrap">指定日期:</span>
                  <select className="text-sm border rounded px-2 py-1 bg-white min-w-[120px]"
                    value={queryDate} onChange={(e) => { const v = e.target.value; setQueryDate(v); if (v) setRankMode("daily"); }}>
                    <option value="">选择日期...</option>
                    {DATE_OPTIONS.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                  {queryDate && <Button variant="ghost" size="sm" className="h-6 text-xs px-2" onClick={() => setQueryDate("")}>清除</Button>}
                </div>
              </div>
              <Badge variant="outline" className="text-gray-500">{badgeLabel}</Badge>
            </div>

            {!hasRealData && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-700 flex items-center gap-2">
                <span>⚠️ 暂无真实数据。请进入「飞书配置」→「立即同步」拉取数据。</span>
              </div>
            )}

            <SummaryCards data={displaySummary} loading={summaryLoading} mode={rankMode} />
            <Leaderboard data={displayLeaderboard as any} loading={leaderboardLoading && !hasRealData}
              mode={rankMode} sortBy={sortBy} onSortChange={setSortBy} title={rankTitle} />
          </TabsContent>

          {/* 每日历史 */}
          <TabsContent value="history" className="space-y-6">
            <DailyHistoryView historyData={dailyHistory as any} />
          </TabsContent>

          {/* 趋势分析 */}
          <TabsContent value="trends" className="space-y-6">
            <SummaryCards data={displaySummary} loading={summaryLoading} mode={rankMode} />
            <TrendChart data={[]} brandData={[]} />
          </TabsContent>

          <TabsContent value="feishu" className="space-y-6">
            <FeishuConfig />
          </TabsContent>

          <TabsContent value="brands" className="space-y-6">
            <BrandManager brands={displayBrands} loading={brandLoading}
              onCreate={(data) => createBrand.mutate(data)}
              onUpdate={(id, data) => updateBrand.mutate({ id, ...data })}
              onDelete={(id) => { if (confirm("确定删除这个品牌吗？")) deleteBrand.mutate({ id }); }} />
          </TabsContent>

          <TabsContent value="guide" className="space-y-6">
            <FeishuGuide />
          </TabsContent>
        </Tabs>
      </main>

      <footer className="bg-white border-t mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <p>星罗618品牌PK看板 · GMV追踪</p>
            <p>数据源自飞书多维表格 · 每小时10分自动同步</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function DailyHistoryView({ historyData }: { historyData?: Array<{ date: string; brandId: number; brandName: string; gmv: number }> }) {
  const [selectedBrand, setSelectedBrand] = useState<string>("all");

  if (!historyData || historyData.length === 0) {
    return (
      <Card className="border-0 shadow-md">
        <CardContent className="p-8 text-center">
          <History className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">暂无历史数据</p>
          <p className="text-xs text-gray-400 mt-1">同步飞书数据后，这里会显示5.20-6.20期间每天的GMV</p>
        </CardContent>
      </Card>
    );
  }

  const dateGroups = new Map<string, Array<{ brandName: string; gmv: number }>>();
  for (const item of historyData) {
    if (selectedBrand !== "all" && item.brandName !== selectedBrand) continue;
    const entry = { brandName: item.brandName, gmv: item.gmv };
    const existing = dateGroups.get(item.date);
    if (existing) existing.push(entry); else dateGroups.set(item.date, [entry]);
  }

  const sortedDates = Array.from(dateGroups.keys()).sort().reverse();
  const allBrands = Array.from(new Set(historyData.map(h => h.brandName))).sort();

  const formatNum = (n: number) => n >= 10000 ? (n / 10000).toFixed(2) + "万" : n >= 1000 ? (n / 1000).toFixed(1) + "K" : n.toLocaleString();

  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <History className="w-5 h-5 text-blue-500" />
              每日历史数据（618期间每天GMV）
            </CardTitle>
            <select className="text-sm border rounded px-2 py-1 bg-white" value={selectedBrand} onChange={(e) => setSelectedBrand(e.target.value)}>
              <option value="all">全部品牌</option>
              {allBrands.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto">
            {sortedDates.map(date => {
              const items = dateGroups.get(date) || [];
              const dayTotalGmv = items.reduce((s, i) => s + i.gmv, 0);
              return (
                <div key={date} className="border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-2 flex items-center justify-between">
                    <span className="font-semibold text-sm">{date}</span>
                    <span className="text-xs text-emerald-600 font-medium">总GMV: ¥{formatNum(dayTotalGmv)}</span>
                  </div>
                  <table className="w-full text-xs">
                    <thead className="bg-gray-50/50"><tr><th className="px-4 py-2 text-left">品牌</th><th className="px-4 py-2 text-right">GMV</th></tr></thead>
                    <tbody>
                      {items.sort((a, b) => b.gmv - a.gmv).map((item, idx) => (
                        <tr key={idx} className="border-t hover:bg-gray-50/50">
                          <td className="px-4 py-2 font-medium">{item.brandName}</td>
                          <td className="px-4 py-2 text-right text-emerald-600 font-medium">¥{formatNum(item.gmv)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
