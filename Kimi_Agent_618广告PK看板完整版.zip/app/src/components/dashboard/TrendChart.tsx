import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  Area, AreaChart, Legend,
} from "recharts";
import { TrendingUp } from "lucide-react";

interface SnapshotData {
  snapshotTime: Date;
  spend: string;
  roi: string;
  gmv: string;
  brandName?: string;
  color?: string;
}

interface TrendChartProps {
  data?: SnapshotData[];
  brandData?: { brandName: string; color: string; snapshots: SnapshotData[] }[];
  loading?: boolean;
}

export function TrendChart({ data, brandData, loading }: TrendChartProps) {
  const formatTime = (date: Date) => {
    const d = new Date(date);
    return `${d.getMonth() + 1}/${d.getDate()} ${d.getHours()}:00`;
  };

  const formatNumber = (num: number | string) => {
    const n = typeof num === "string" ? parseFloat(num) : num;
    if (isNaN(n)) return "0";
    if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
    if (n >= 10000) return `${(n / 10000).toFixed(1)}万`;
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
    return n.toLocaleString();
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border rounded-lg shadow-lg text-sm">
          <p className="text-gray-500 mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} style={{ color: entry.color }} className="font-medium">
              {entry.name}: {entry.name === "ROI" ? `${entry.value}` : `¥${formatNumber(entry.value)}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  if (loading) {
    return (
      <Card className="border-0 shadow-md">
        <CardContent className="p-8">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4" />
            <div className="h-80 bg-gray-100 rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  const chartData = data?.map((d) => ({
    time: formatTime(d.snapshotTime),
    消耗: parseFloat(d.spend || "0"),
    GMV: parseFloat(d.gmv || "0"),
    ROI: parseFloat(d.roi || "0"),
  })) || [];

  const brandChartData = brandData?.map((bd) => ({
    name: bd.brandName,
    color: bd.color,
    data: bd.snapshots.map((s) => ({
      time: formatTime(s.snapshotTime),
      消耗: parseFloat(s.spend || "0"),
      GMV: parseFloat(s.gmv || "0"),
      ROI: parseFloat(s.roi || "0"),
    })),
  }));

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-blue-500" />
          千川数据趋势
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="spend" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="spend">消耗趋势</TabsTrigger>
            <TabsTrigger value="gmv">GMV趋势</TabsTrigger>
            <TabsTrigger value="roi">ROI趋势</TabsTrigger>
          </TabsList>

          <TabsContent value="spend" className="mt-4">
            <ResponsiveContainer width="100%" height={360}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="spendGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => formatNumber(v)} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area type="monotone" dataKey="消耗" stroke="#ef4444" fill="url(#spendGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="gmv" className="mt-4">
            <ResponsiveContainer width="100%" height={360}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="gmvGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => formatNumber(v)} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                <Area type="monotone" dataKey="GMV" stroke="#10b981" fill="url(#gmvGrad)" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </TabsContent>

          <TabsContent value="roi" className="mt-4">
            <ResponsiveContainer width="100%" height={360}>
              <LineChart
                data={brandChartData && brandChartData.length > 0 ? brandChartData[0].data : chartData}
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="time" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                {brandChartData && brandChartData.length > 0
                  ? brandChartData.map((bd, idx) => (
                      <Line key={idx} type="monotone" dataKey="ROI" data={bd.data} name={bd.name}
                        stroke={bd.color || "#3b82f6"} strokeWidth={2} dot={false} />
                    ))
                  : <Line type="monotone" dataKey="ROI" stroke="#3b82f6" strokeWidth={2} dot={false} />
                }
              </LineChart>
            </ResponsiveContainer>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
