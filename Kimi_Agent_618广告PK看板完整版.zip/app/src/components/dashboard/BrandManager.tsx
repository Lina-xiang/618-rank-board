import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Pencil, Trash2, Plus, Settings } from "lucide-react";

interface Brand {
  id: number;
  name: string;
  accountId: string;
  logo?: string | null;
  teamName: string;
  targetGmv: string;
  targetSpend: string;
  color?: string | null;
  sortOrder?: number | null;
  isActive?: number | null;
  createdAt: Date;
}

interface BrandManagerProps {
  brands?: Brand[];
  loading?: boolean;
  onCreate?: (data: any) => void;
  onUpdate?: (id: number, data: any) => void;
  onDelete?: (id: number) => void;
}

const PRESET_COLORS = [
  "#ef4444", "#f97316", "#eab308", "#84cc16", "#22c55e",
  "#10b981", "#14b8a6", "#06b6d4", "#3b82f6", "#6366f1",
  "#8b5cf6", "#a855f7", "#d946ef", "#ec4899", "#f43f5e",
];

export function BrandManager({ brands, loading, onCreate, onUpdate, onDelete }: BrandManagerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [editingBrand, setEditingBrand] = useState<Brand | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    accountId: "",
    teamName: "",
    targetGmv: "",
    targetSpend: "",
    color: "#3b82f6",
    sortOrder: 0,
  });

  const resetForm = () => {
    setFormData({
      name: "",
      accountId: "",
      teamName: "",
      targetGmv: "",
      targetSpend: "",
      color: "#3b82f6",
      sortOrder: 0,
    });
    setEditingBrand(null);
  };

  const handleEdit = (brand: Brand) => {
    setEditingBrand(brand);
    setFormData({
      name: brand.name,
      accountId: brand.accountId,
      teamName: brand.teamName,
      targetGmv: brand.targetGmv,
      targetSpend: brand.targetSpend || "",
      color: brand.color || "#3b82f6",
      sortOrder: brand.sortOrder || 0,
    });
    setIsOpen(true);
  };

  const handleSubmit = () => {
    if (editingBrand) {
      onUpdate?.(editingBrand.id, formData);
    } else {
      onCreate?.(formData);
    }
    setIsOpen(false);
    resetForm();
  };

  const formatNumber = (num: string) => {
    const n = parseFloat(num);
    if (isNaN(n)) return "0";
    if (n >= 100000000) return `${(n / 100000000).toFixed(2)}亿`;
    if (n >= 10000) return `${(n / 10000).toFixed(2)}万`;
    return n.toLocaleString();
  };

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-bold flex items-center gap-2">
            <Settings className="w-5 h-5 text-gray-500" />
            品牌管理
          </CardTitle>
          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={resetForm}>
                <Plus className="w-4 h-4 mr-1" />
                添加品牌
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>
                  {editingBrand ? "编辑品牌" : "添加品牌"}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>品牌名称</Label>
                    <Input
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({ ...formData, name: e.target.value })
                      }
                      placeholder="如: 花西子"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>千川广告账户ID</Label>
                    <Input
                      value={formData.accountId}
                      onChange={(e) =>
                        setFormData({ ...formData, accountId: e.target.value })
                      }
                      placeholder="如: huaxizi_ad"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>团队名称</Label>
                    <Input
                      value={formData.teamName}
                      onChange={(e) =>
                        setFormData({ ...formData, teamName: e.target.value })
                      }
                      placeholder="如: A组·美妆战队"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>目标GMV (元)</Label>
                    <Input
                      type="number"
                      value={formData.targetGmv}
                      onChange={(e) =>
                        setFormData({ ...formData, targetGmv: e.target.value })
                      }
                      placeholder="如: 5000000"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>消耗预算 (元)</Label>
                    <Input
                      type="number"
                      value={formData.targetSpend}
                      onChange={(e) =>
                        setFormData({ ...formData, targetSpend: e.target.value })
                      }
                      placeholder="如: 2000000"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>排序权重</Label>
                    <Input
                      type="number"
                      value={formData.sortOrder}
                      onChange={(e) =>
                        setFormData({ ...formData, sortOrder: parseInt(e.target.value) || 0 })
                      }
                      placeholder="如: 10"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>品牌色</Label>
                  <div className="flex flex-wrap gap-2">
                    {PRESET_COLORS.map((c) => (
                      <button
                        key={c}
                        className={`w-8 h-8 rounded-full transition-transform ${
                          formData.color === c
                            ? "ring-2 ring-offset-2 ring-gray-400 scale-110"
                            : "hover:scale-105"
                        }`}
                        style={{ backgroundColor: c }}
                        onClick={() => setFormData({ ...formData, color: c })}
                      />
                    ))}
                  </div>
                </div>
                <div className="pt-2 flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsOpen(false)}>
                    取消
                  </Button>
                  <Button onClick={handleSubmit}>
                    {editingBrand ? "保存修改" : "添加品牌"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="animate-pulse space-y-2">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-12 bg-gray-100 rounded" />
            ))}
          </div>
        ) : !brands || brands.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            暂无品牌，点击「添加品牌」开始配置
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>品牌</TableHead>
                <TableHead>团队</TableHead>
                <TableHead>千川账户</TableHead>
                <TableHead className="text-right">目标GMV</TableHead>
                <TableHead className="text-right">消耗预算</TableHead>
                <TableHead className="text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {brands.map((brand) => (
                <TableRow key={brand.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <div
                        className="w-6 h-6 rounded-full"
                        style={{ backgroundColor: brand.color || "#3b82f6" }}
                      />
                      <span className="font-medium">{brand.name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-sm text-gray-500">
                    {brand.teamName}
                  </TableCell>
                  <TableCell className="text-sm font-mono text-gray-500">
                    {brand.accountId}
                  </TableCell>
                  <TableCell className="text-right text-sm">
                    ¥{formatNumber(brand.targetGmv)}
                  </TableCell>
                  <TableCell className="text-right text-sm">
                    ¥{formatNumber(brand.targetSpend)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleEdit(brand)}
                      >
                        <Pencil className="w-4 h-4 text-gray-500" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => onDelete?.(brand.id)}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
