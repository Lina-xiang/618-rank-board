import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { trpc } from "@/providers/trpc";
import { toast } from "sonner";
import { Link2, Save, TestTube, RefreshCw, CheckCircle, AlertCircle, Clock, FileSpreadsheet, Stethoscope, Wifi, WifiOff } from "lucide-react";

const DEFAULT_FIELD_MAPPING = {
  brandName: "品牌",
  teamName: "团队",
  spend: "消耗",
  roi: "ROI",
  gmv: "GMV",
  snapshotTime: "时间",
};

export function FeishuConfig() {
  const [appId, setAppId] = useState("");
  const [appSecret, setAppSecret] = useState("");
  const [appToken, setAppToken] = useState("");
  const [tableId, setTableId] = useState("");
  const [fieldMapping, setFieldMapping] = useState(JSON.stringify(DEFAULT_FIELD_MAPPING, null, 2));
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [showDiagnose, setShowDiagnose] = useState(false);
  const [saving, setSaving] = useState(false);
  const [apiOnline, setApiOnline] = useState<boolean | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // 检测 API 是否在线
  useEffect(() => {
    fetch("/api/trpc/ping")
      .then((r) => setApiOnline(r.ok))
      .catch(() => setApiOnline(false));
  }, []);

  const utils = trpc.useUtils();
  const { data: config } = trpc.feishu.getConfig.useQuery();
  const { data: logs } = trpc.feishu.syncLogs.useQuery({ limit: 10 });
  const { data: snapshotStats } = trpc.leaderboard.snapshotStats.useQuery();

  const { data: diagnoseRaw, refetch: refetchDiagnose } = trpc.feishu.diagnose.useQuery(
    { configId: config?.id || 0 },
    { enabled: !!config?.id && showDiagnose }
  );
  const diagnoseData = diagnoseRaw as any;

  // 加载已有配置
  useEffect(() => {
    if (config) {
      setAppId(config.appId || "");
      setAppSecret(config.appSecret || "");
      setAppToken(config.appToken || "");
      setTableId(config.tableId || "");
      if (config.fieldMapping) setFieldMapping(config.fieldMapping);
    }
  }, [config]);

  const saveConfigMutation = trpc.feishu.saveConfig.useMutation({
    onSuccess: (data) => {
      setSaving(false);
      setSaveError(null);
      toast.success("飞书配置已保存 (ID: " + data.id + ")");
      utils.feishu.getConfig.invalidate();
    },
    onError: (err: any) => {
      setSaving(false);
      console.error("[SaveConfig Error]", err);
      const detail = err.data?.code ? `[${err.data.code}] ` : "";
      setSaveError(detail + (err.message || "tRPC 请求失败"));
      toast.error("保存失败: " + detail + (err.message || "未知错误"));
    },
  });

  // Fallback: 直接 fetch 保存配置（当 tRPC 不可用时）
  const saveViaFetch = async () => {
    setSaving(true);
    setSaveError(null);
    try {
      const res = await fetch("/api/trpc/feishu.saveConfig", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          json: { appId, appSecret, appToken, tableId, fieldMapping },
        }),
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`HTTP ${res.status}: ${text.slice(0, 200)}`);
      }
      const data = await res.json();
      if (data.result?.data?.json?.success) {
        setSaving(false);
        toast.success("配置已保存 (fallback 模式, ID: " + data.result.data.json.id + ")");
        utils.feishu.getConfig.invalidate();
      } else {
        throw new Error("响应格式异常");
      }
    } catch (err: any) {
      setSaving(false);
      setSaveError(err.message);
      toast.error("Fallback 保存也失败: " + err.message);
    }
  };

  const testConnectionMutation = trpc.feishu.testConnection.useMutation({
    onSuccess: (data) => {
      setTestResult(data);
      if ("success" in data && data.success) {
        toast.success(`连接成功！共 ${data.totalRecords} 条记录`);
      } else {
        const errorMsg = "error" in data ? data.error : "连接失败";
        if (errorMsg.includes("tenant_access_token") || errorMsg.includes("app secret") || errorMsg.includes("invalid")) {
          setTestResult({ error: errorMsg, isAuthError: true });
          toast.error("飞书认证失败：App ID 或 App Secret 不正确", { duration: 5000 });
        } else {
          toast.error(errorMsg);
        }
      }
    },
    onError: (err: any) => {
      setTesting(false);
      toast.error("测试失败: " + err.message);
    },
  });

  const syncDataMutation = trpc.feishu.sync.useMutation({
    onSuccess: (data) => {
      if ("success" in data && data.success) {
        toast.success(`同步完成！${(data as any).snapshotsCreated || 0} 条快照`);
        if ((data as any).brandsSkipped > 0) {
          toast.warning(`${(data as any).brandsSkipped} 条记录品牌名未匹配，请检查诊断信息`);
        }
        utils.leaderboard.summary.invalidate();
        utils.leaderboard.get.invalidate();
        utils.leaderboard.snapshotStats.invalidate();
        utils.feishu.syncLogs.invalidate();
        if (showDiagnose) refetchDiagnose();
      } else {
        const errorMsg = (data as any)?.error || "同步失败";
        if (errorMsg.includes("tenant_access_token") || errorMsg.includes("app secret") || errorMsg.includes("invalid")) {
          toast.error("飞书认证失败：App Secret 无效或已过期，请检查配置", { duration: 5000 });
        } else {
          toast.error(errorMsg);
        }
      }
    },
    onError: (err: any) => toast.error(err.message),
  });

  const handleSave = async () => {
    try { JSON.parse(fieldMapping); } catch { toast.error("字段映射不是有效的 JSON"); return; }
    setSaving(true);
    setSaveError(null);

    // 方式1：tRPC mutation
    try {
      const result = await saveConfigMutation.mutateAsync({
        appId, appSecret, appToken, tableId, fieldMapping,
      });
      toast.success("配置已保存 (ID: " + result.id + ")");
      utils.feishu.getConfig.invalidate();
      setSaving(false);
      return;
    } catch (trpcErr: any) {
      console.log("[Save] tRPC failed:", trpcErr.message);
    }

    // 方式2：fallback 直接 fetch
    try {
      await saveViaFetch();
    } catch {
      // saveViaFetch 内部已处理错误
    }
  };

  const handleTest = () => {
    setTesting(true); setTestResult(null);
    testConnectionMutation.mutate(
      { appId, appSecret, appToken, tableId },
      { onSettled: () => setTesting(false) }
    );
  };

  const handleSync = () => {
    if (!config?.id) { toast.error("请先保存配置"); return; }
    syncDataMutation.mutate({ configId: config.id });
  };

  const extractTokenFromUrl = (url: string) => {
    try {
      const match = url.match(/\/base\/([a-zA-Z0-9]+)/);
      if (match) setAppToken(match[1]);
      const tableMatch = url.match(/[?&]table=([a-zA-Z0-9]+)/);
      if (tableMatch) setTableId(tableMatch[1]);
      toast.success("已从链接中提取参数");
    } catch { toast.error("无法从链接中提取参数"); }
  };

  return (
    <div className="space-y-6">
      {/* 飞书配置卡片 */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Link2 className="w-5 h-5 text-blue-500" />飞书多维表格配置
            </CardTitle>
            <div className="flex items-center gap-2">
              {apiOnline === true && (
                <Badge variant="outline" className="text-emerald-600 border-emerald-200 bg-emerald-50">
                  <Wifi className="w-3 h-3 mr-1" />API 在线
                </Badge>
              )}
              {apiOnline === false && (
                <Badge variant="outline" className="text-red-600 border-red-200 bg-red-50" title="后端 API 未运行，请在本地运行 npm run dev">
                  <WifiOff className="w-3 h-3 mr-1" />API 离线
                </Badge>
              )}
              <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50">
                <FileSpreadsheet className="w-3 h-3 mr-1" />数据源
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-5">
          <div className="space-y-2">
            <Label className="text-sm text-gray-500">快速提取（粘贴多维表格链接）</Label>
            <Input placeholder="https://xxx.feishu.cn/base/XXXX?table=XXXX"
              onChange={(e) => { if (e.target.value.includes("/base/")) { extractTokenFromUrl(e.target.value); e.target.value = ""; } }} />
            <p className="text-xs text-gray-400">复制飞书表格链接粘贴，自动提取 app_token 和 table_id</p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>App ID *</Label>
              <Input value={appId} onChange={(e) => setAppId(e.target.value)} placeholder="cli_xxxxxxxxxx" required />
              <p className="text-xs text-gray-400">飞书开放平台应用的 App ID</p>
            </div>
            <div className="space-y-2">
              <Label>App Secret *</Label>
              <Input type="password" value={appSecret} onChange={(e) => setAppSecret(e.target.value)} placeholder="从飞书开发者后台获取" required />
              <p className="text-xs text-gray-400">飞书开放平台应用的 App Secret</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>App Token *</Label>
              <Input value={appToken} onChange={(e) => setAppToken(e.target.value)} placeholder="多维表格 ID" required />
            </div>
            <div className="space-y-2">
              <Label>Table ID *</Label>
              <Input value={tableId} onChange={(e) => setTableId(e.target.value)} placeholder="数据表 ID" required />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label>字段映射（JSON）</Label>
              <Button variant="ghost" size="sm" className="h-7 text-xs"
                onClick={() => setFieldMapping(JSON.stringify(DEFAULT_FIELD_MAPPING, null, 2))}>恢复默认</Button>
            </div>
            <Textarea value={fieldMapping} onChange={(e) => setFieldMapping(e.target.value)} rows={7} className="font-mono text-xs" />
            <p className="text-xs text-gray-400">右侧值为飞书表格中的列名，确保与你的表格列名一致</p>
          </div>

          <div className="flex gap-2 flex-wrap">
            <Button onClick={handleSave} disabled={saving || saveConfigMutation.isPending}>
              <Save className="w-4 h-4 mr-1" />{saving || saveConfigMutation.isPending ? "保存中..." : "保存配置"}
            </Button>
            <Button variant="outline" onClick={handleTest} disabled={testing}>
              <TestTube className="w-4 h-4 mr-1" />{testing ? "测试中..." : "测试连接"}
            </Button>
            <Button variant="default" onClick={handleSync} disabled={syncDataMutation.isPending || !config?.id}
              className="bg-emerald-600 hover:bg-emerald-700">
              <RefreshCw className={`w-4 h-4 mr-1 ${syncDataMutation.isPending ? "animate-spin" : ""}`} />
              {syncDataMutation.isPending ? "同步中..." : "立即同步"}
            </Button>
            <Button variant="outline" onClick={() => { setShowDiagnose(!showDiagnose); if (!showDiagnose) refetchDiagnose(); }}>
              <Stethoscope className="w-4 h-4 mr-1" />诊断
            </Button>
          </div>

          {saveError && (
            <div className="p-3 rounded-lg border border-red-200 bg-red-50 text-sm text-red-700">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">保存失败</p>
                  <p className="text-red-600">{saveError}</p>
                  {apiOnline === false && (
                    <p className="text-red-500 mt-1 text-xs">
                      后端 API 未运行。请在本地终端执行 <code className="bg-red-100 px-1 rounded">npm run dev</code> 启动完整服务（含后端）。
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}

          {testResult && (
            <div className={`p-3 rounded-lg border ${"success" in testResult && testResult.success ? "bg-emerald-50 border-emerald-200" : "bg-red-50 border-red-200"}`}>
              <div className="flex items-start gap-2">
                {"success" in testResult && testResult.success ? <CheckCircle className="w-4 h-4 text-emerald-600 mt-0.5" /> : <AlertCircle className="w-4 h-4 text-red-600 mt-0.5" />}
                <div className="text-sm">
                  {"success" in testResult && testResult.success ? (
                    <div className="space-y-1">
                      <p className="font-medium text-emerald-700">连接成功</p>
                      <p className="text-emerald-600">共 {testResult.totalRecords} 条记录</p>
                      {testResult.sampleFields?.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-emerald-500 mb-1">可用字段：</p>
                          <div className="flex flex-wrap gap-1">
                            {testResult.sampleFields.map((f: string) => (
                              <Badge key={f} variant="outline" className="text-xs bg-white">{f}</Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <p className="text-red-600 font-medium">{"error" in testResult ? testResult.error : "连接失败"}</p>
                      {(testResult as any)?.isAuthError && (
                        <div className="text-xs text-red-500 space-y-1 bg-red-100/50 rounded p-2">
                          <p>排查步骤：</p>
                          <p>1. 打开 <a href="https://open.feishu.cn/app" target="_blank" rel="noopener noreferrer" className="underline">飞书开放平台</a></p>
                          <p>2. 确认应用状态为「已启用」</p>
                          <p>3. 点击「凭证与基础信息」重新复制 App Secret</p>
                          <p>4. 确保应用有「多维表格」权限（bitable:records:read）</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 诊断面板 */}
      {showDiagnose && (
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-orange-500" />品牌名匹配诊断
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {diagnoseData ? (
              <>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-emerald-50 rounded-lg p-3 border border-emerald-200 text-center">
                    <p className="text-2xl font-bold text-emerald-600">{diagnoseData.matched?.length || 0}</p>
                    <p className="text-xs text-emerald-500">飞书品牌匹配成功</p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-3 border border-red-200 text-center">
                    <p className="text-2xl font-bold text-red-600">{diagnoseData.unmatched?.length || 0}</p>
                    <p className="text-xs text-red-500">飞书品牌名不在看板中</p>
                  </div>
                  <div className="bg-yellow-50 rounded-lg p-3 border border-yellow-200 text-center">
                    <p className="text-2xl font-bold text-yellow-600">{diagnoseData.missingInFeishu?.length || 0}</p>
                    <p className="text-xs text-yellow-500">看板品牌飞书中缺失</p>
                  </div>
                </div>

                {diagnoseData.unmatched && diagnoseData.unmatched.length > 0 && (
                  <div className="bg-red-50 rounded-lg p-3 border border-red-200">
                    <p className="text-sm font-medium text-red-700 mb-2">以下飞书品牌名在看板中找不到（将被跳过）：</p>
                    <div className="flex flex-wrap gap-1">
                      {diagnoseData.unmatched.map((name: string) => (
                        <Badge key={name} variant="outline" className="bg-white text-red-600 border-red-200">{name}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {diagnoseData.missingInFeishu && diagnoseData.missingInFeishu.length > 0 && (
                  <div className="bg-yellow-50 rounded-lg p-3 border border-yellow-200">
                    <p className="text-sm font-medium text-yellow-700 mb-2">以下看板品牌在飞书表格中找不到：</p>
                    <div className="flex flex-wrap gap-1">
                      {diagnoseData.missingInFeishu.map((name: string) => (
                        <Badge key={name} variant="outline" className="bg-white text-yellow-600 border-yellow-200">{name}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <p className="font-medium text-gray-500 mb-1">看板中的品牌 ({diagnoseData.dashboardBrandNames?.length || 0})</p>
                    <div className="space-y-1 max-h-60 overflow-y-auto">
                      {diagnoseData.dashboardBrandNames?.map((name: string) => (
                        <div key={name} className={`px-2 py-1 rounded ${diagnoseData.matched?.includes(name) ? "bg-emerald-50 text-emerald-700" : "bg-yellow-50 text-yellow-700"}`}>
                          {name} {diagnoseData.matched?.includes(name) ? "✓" : "⚠缺失"}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="font-medium text-gray-500 mb-1">飞书表格中的品牌 ({diagnoseData.feishuBrandNames?.length || 0})</p>
                    <div className="space-y-1 max-h-60 overflow-y-auto">
                      {diagnoseData.feishuBrandNames?.map((name: string) => (
                        <div key={name} className={`px-2 py-1 rounded ${diagnoseData.matched?.includes(name) ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`}>
                          {name} {diagnoseData.matched?.includes(name) ? "✓" : "✗不匹配"}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {diagnoseData.error && (
                  <div className="bg-red-50 rounded-lg p-3 border border-red-200 text-sm text-red-600">{diagnoseData.error}</div>
                )}

                {/* 时间列格式诊断 */}
                {diagnoseData.timeAnalysis && (
                  <div className="border rounded-lg p-4 space-y-3">
                    <p className="font-medium text-sm flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-500" />
                      时间列「{diagnoseData.timeAnalysis.timeFieldName}」格式检查
                    </p>
                    <div className="grid grid-cols-4 gap-3 text-center">
                      <div className="bg-emerald-50 rounded p-2 border border-emerald-200">
                        <p className="text-xl font-bold text-emerald-600">{diagnoseData.timeAnalysis.validDate}</p>
                        <p className="text-xs text-emerald-500">格式正确</p>
                      </div>
                      <div className="bg-red-50 rounded p-2 border border-red-200">
                        <p className="text-xl font-bold text-red-600">{diagnoseData.timeAnalysis.invalidDate}</p>
                        <p className="text-xs text-red-500">格式错误</p>
                      </div>
                      <div className="bg-yellow-50 rounded p-2 border border-yellow-200">
                        <p className="text-xl font-bold text-yellow-600">{diagnoseData.timeAnalysis.emptyDate}</p>
                        <p className="text-xs text-yellow-500">为空</p>
                      </div>
                      <div className="bg-gray-50 rounded p-2 border border-gray-200">
                        <p className="text-xl font-bold text-gray-600">{diagnoseData.timeAnalysis.totalRecords}</p>
                        <p className="text-xs text-gray-500">总记录</p>
                      </div>
                    </div>

                    {diagnoseData.timeAnalysis.validDate > 0 && (
                      <div>
                        <p className="text-xs text-gray-500 mb-1">日期分布（UTC）:</p>
                        <div className="flex flex-wrap gap-1">
                          {Object.entries(diagnoseData.timeAnalysis.dateDistribution).sort().reverse().map(([date, count]: [string, any]) => (
                            <Badge key={date} variant="outline" className="text-xs bg-blue-50 text-blue-600 border-blue-200">
                              {date}: {count}条
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {diagnoseData.timeAnalysis.emptyDate > 0 && (
                      <div className="bg-yellow-50 rounded p-2 border border-yellow-200 text-xs text-yellow-700">
                        ⚠️ {diagnoseData.timeAnalysis.emptyDate} 条记录时间列为空，同步时会使用当前时间（{new Date().toISOString().slice(0,10)}）。
                        如果你补充的是5月20日的数据，时间列必须填写「2026-05-20」才能正确归档。
                      </div>
                    )}

                    {diagnoseData.timeAnalysis.invalidDate > 0 && (
                      <div className="bg-red-50 rounded p-2 border border-red-200 text-xs text-red-700">
                        <p>⚠️ {diagnoseData.timeAnalysis.invalidDate} 条记录时间列格式无法解析。错误示例：</p>
                        {diagnoseData.timeAnalysis.sampleInvalid.map((s: string, i: number) => (
                          <p key={i} className="font-mono mt-1">「{s}」→ 无法解析</p>
                        ))}
                        <p className="mt-1">正确格式：2026-05-20 或 2026/05/20</p>
                      </div>
                    )}
                  </div>
                )}
              </>
            ) : (
              <div className="text-center text-gray-500 text-sm">请先保存配置，然后点击诊断</div>
            )}
          </CardContent>
        </Card>
      )}

      {/* 快照统计 */}
      {snapshotStats && snapshotStats.length > 0 && (
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-gray-500" />数据快照统计
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>品牌</TableHead>
                  <TableHead className="text-right">快照数</TableHead>
                  <TableHead className="text-right">最新消耗</TableHead>
                  <TableHead className="text-right">最新ROI</TableHead>
                  <TableHead className="text-right">最新GMV</TableHead>
                  <TableHead className="text-right">累计消耗</TableHead>
                  <TableHead className="text-right">累计GMV</TableHead>
                  <TableHead className="text-right">最新时间</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {snapshotStats.map((s: any) => (
                  <TableRow key={s.brandId} className={s.snapshotCount === 0 ? "bg-gray-50" : ""}>
                    <TableCell>
                      <span className="font-medium text-sm">{s.brandName}</span>
                      <span className="text-xs text-gray-400 ml-2">{s.teamName}</span>
                    </TableCell>
                    <TableCell className="text-right">
                      {s.snapshotCount > 0 ? (
                        <Badge variant="outline" className="bg-emerald-50 text-emerald-600">{s.snapshotCount}</Badge>
                      ) : (
                        <Badge variant="outline" className="bg-gray-100 text-gray-400">0</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-sm">
                      {s.latestSpend !== null && s.latestSpend !== undefined && s.latestSpend !== "null" ? (
                        <span title={`raw: ${JSON.stringify(s.latestSpend)}`}>¥{Number(s.latestSpend).toLocaleString()}</span>
                      ) : (
                        <span className="text-red-500" title={`raw: ${JSON.stringify(s.latestSpend)}`}>-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-sm">
                      {s.latestRoi !== null && s.latestRoi !== undefined && s.latestRoi !== "null" ? (
                        <span title={`raw: ${JSON.stringify(s.latestRoi)}`}>{Number(s.latestRoi).toFixed(2)}</span>
                      ) : (
                        <span className="text-red-500" title={`raw: ${JSON.stringify(s.latestRoi)}`}>-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-sm">
                      {s.latestGmv !== null && s.latestGmv !== undefined && s.latestGmv !== "null" ? (
                        <span title={`raw: ${JSON.stringify(s.latestGmv)}`}>¥{Number(s.latestGmv).toLocaleString()}</span>
                      ) : (
                        <span className="text-red-500" title={`raw: ${JSON.stringify(s.latestGmv)}`}>-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-sm">¥{Number(s.totalSpend).toLocaleString()}</TableCell>
                    <TableCell className="text-right text-sm">¥{Number(s.totalGmv).toLocaleString()}</TableCell>
                    <TableCell className="text-right text-xs text-gray-400">
                      {s.latestTime ? new Date(s.latestTime).toLocaleString() : "-"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* 同步日志 */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold flex items-center gap-2">
            <Clock className="w-5 h-5 text-gray-500" />同步历史
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!logs || logs.length === 0 ? (
            <div className="text-center py-6 text-gray-500 text-sm">暂无同步记录，点击「立即同步」开始</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-24">状态</TableHead>
                  <TableHead>处理</TableHead>
                  <TableHead>匹配</TableHead>
                  <TableHead>结果</TableHead>
                  <TableHead className="text-right">时间</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log: any) => (
                  <TableRow key={log.id}>
                    <TableCell>
                      {log.status === "success" && (
                        <Badge variant="outline" className="bg-emerald-50 text-emerald-600 border-emerald-200">
                          <CheckCircle className="w-3 h-3 mr-1" />成功
                        </Badge>
                      )}
                      {log.status === "failed" && (
                        <Badge variant="outline" className="bg-red-50 text-red-600 border-red-200">
                          <AlertCircle className="w-3 h-3 mr-1" />失败
                        </Badge>
                      )}
                      {log.status === "running" && (
                        <Badge variant="outline" className="bg-blue-50 text-blue-600 border-blue-200">
                          <RefreshCw className="w-3 h-3 mr-1 animate-spin" />同步中
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-sm">{log.recordsProcessed || 0} 条</TableCell>
                    <TableCell className="text-sm">{log.brandsMatched || 0} 个</TableCell>
                    <TableCell className="text-sm text-gray-500 max-w-xs truncate">{log.message || log.errorDetail || "-"}</TableCell>
                    <TableCell className="text-right text-xs text-gray-400">
                      {log.completedAt ? new Date(log.completedAt).toLocaleString() : "-"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
