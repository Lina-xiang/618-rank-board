import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Target } from "lucide-react";

interface SummaryData {
  totalBrands: number;
  activeBrands: number;
  totalSpend: string;
  totalGmv: string;
  totalTarget: string;
  totalSpendTarget: string;
  overallRoi: string;
  overallProgress: string;
}

interface SummaryCardsProps {
  data?: SummaryData;
  loading?: boolean;
  mode?: "daily" | "total618";
}

export function SummaryCards({ data, loading, mode = "daily" }: SummaryCardsProps) {
  if (loading || !data) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {[1, 2].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6 h-28 bg-gray-100" />
          </Card>
        ))}
      </div>
    );
  }

  const formatNumber = (num: number | string) => {
    const n = typeof num === "string" ? parseFloat(num) : num;
    if (isNaN(n)) return "0";
    if (n >= 100000000) return `${(n / 100000000).toFixed(2)}亿`;
    if (n >= 10000) return `${(n / 10000).toFixed(2)}万`;
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
    return n.toLocaleString();
  };

  const modeLabel = mode === "daily" ? "今日" : "618累计";

  const cards = [
    {
      title: `${modeLabel}GMV`,
      value: `¥${formatNumber(data.totalGmv)}`,
      subtitle: `目标: ¥${formatNumber(data.totalTarget)}`,
      progress: parseFloat(data.overallProgress || "0"),
      icon: TrendingUp,
      color: "text-emerald-500",
      bgColor: "bg-emerald-50",
      progressColor: "bg-emerald-500",
    },
    {
      title: "目标达成率",
      value: `${data.overallProgress}%`,
      subtitle: `${data.activeBrands}/${data.totalBrands} 品牌有成交`,
      progress: parseFloat(data.overallProgress || "0"),
      icon: Target,
      color: "text-blue-500",
      bgColor: "bg-blue-50",
      progressColor: "bg-blue-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {cards.map((card) => (
        <Card key={card.title} className="border-0 shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm text-gray-500 mb-1">{card.title}</p>
                <p className={`text-2xl font-bold ${card.color}`}>{card.value}</p>
                <p className="text-xs text-gray-400 mt-1">{card.subtitle}</p>
                {card.progress !== undefined && card.progress > 0 && (
                  <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${card.progressColor}`}
                      style={{ width: `${Math.min(card.progress, 100)}%` }}
                    />
                  </div>
                )}
              </div>
              <div className={`${card.bgColor} p-3 rounded-xl`}>
                <card.icon className={`w-5 h-5 ${card.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
