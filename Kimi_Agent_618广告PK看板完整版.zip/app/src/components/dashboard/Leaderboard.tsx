import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Trophy, TrendingUp, TrendingDown, Minus, ArrowUpDown } from "lucide-react";
import { useState } from "react";

interface Item {
  rank: number; brandId: number; brandName: string; teamName: string;
  color?: string | null; targetGmv: string; targetSpend: string;
  spend: string; roi: string; gmv: string; progress?: string;
  lastUpdated?: Date | null; dataSource?: string;
}

interface Props {
  data?: Item[]; loading?: boolean; mode?: "daily" | "total618";
  sortBy?: string; onSortChange?: (sort: string) => void; title?: string;
}

const rankBadges: Record<number, { color: string; bg: string; label: string }> = {
  1: { color: "text-yellow-500", bg: "bg-yellow-50 border-yellow-200", label: "冠军" },
  2: { color: "text-gray-400", bg: "bg-gray-50 border-gray-200", label: "亚军" },
  3: { color: "text-amber-600", bg: "bg-amber-50 border-amber-200", label: "季军" },
};

export function Leaderboard({ data, loading, mode = "daily", sortBy = "gmv", onSortChange, title }: Props) {
  const [localSort, setLocalSort] = useState(sortBy);

  const handleSort = (field: string) => { setLocalSort(field); onSortChange?.(field); };

  const fmt = (num: number | string | null | undefined) => {
    if (num === null || num === undefined) return "0";
    const n = typeof num === "string" ? parseFloat(num) : num;
    if (isNaN(n)) return "0";
    if (n >= 100000000) return `${(n / 100000000).toFixed(2)}亿`;
    if (n >= 10000) return `${(n / 10000).toFixed(2)}万`;
    if (n >= 1000) return `${(n / 1000).toFixed(1)}K`;
    return n.toLocaleString();
  };

  const getRankBadge = (rank: number) => {
    const c = rankBadges[rank];
    if (c) return <Badge variant="outline" className={`${c.bg} ${c.color} font-bold`}><Trophy className="w-3 h-3 mr-1" />{c.label}</Badge>;
    return <Badge variant="outline" className="text-gray-500">第{rank}名</Badge>;
  };

  if (loading) return (
    <Card className="border-0 shadow-md"><CardContent className="p-8">
      <div className="animate-pulse space-y-4"><div className="h-8 bg-gray-200 rounded w-1/4" /><div className="h-64 bg-gray-100 rounded" /></div>
    </CardContent></Card>
  );

  if (!data || data.length === 0) return (
    <Card className="border-0 shadow-md"><CardContent className="p-8 text-center">
      <p className="text-gray-500">暂无数据，请配置飞书多维表格并同步</p>
    </CardContent></Card>
  );

  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <CardTitle className="text-lg font-bold flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            {title || (mode === "daily" ? "今日实时排名" : "618总排名（5.20-6.20）")}
          </CardTitle>
          <div className="flex gap-2">
            {[
              { key: "gmv", label: "按GMV" },
            ].map((opt) => (
              <Button key={opt.key} variant={localSort === opt.key ? "default" : "outline"} size="sm" onClick={() => handleSort(opt.key)} className="text-xs">
                <ArrowUpDown className="w-3 h-3 mr-1" />{opt.label}
              </Button>
            ))}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-16 text-center">排名</TableHead>
                <TableHead>品牌</TableHead>
                <TableHead className="text-right">GMV</TableHead>
                <TableHead className="text-right">来源</TableHead>
                <TableHead className="w-48">目标进度</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((item) => {
                const progress = parseFloat(item.progress || "0");
                return (
                  <TableRow key={item.brandId} className="hover:bg-gray-50/50">
                    <TableCell className="text-center">
                      <div className="flex flex-col items-center gap-1">
                        {getRankBadge(item.rank)}
                        {item.rank <= 2 ? <TrendingUp className="w-4 h-4 text-emerald-500" /> : item.rank >= 6 ? <TrendingDown className="w-4 h-4 text-red-500" /> : <Minus className="w-4 h-4 text-gray-400" />}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-sm shadow-sm flex-shrink-0" style={{ backgroundColor: item.color || "#3b82f6" }}>
                          {item.brandName.slice(0, 1)}
                        </div>
                        <div>
                          <p className="font-semibold text-sm">{item.brandName}</p>
                          <p className="text-xs text-gray-500">{item.teamName}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <p className="font-bold text-emerald-600">¥{fmt(item.gmv)}</p>
                      <p className="text-xs text-gray-400">目标: ¥{fmt(item.targetGmv)}</p>
                    </TableCell>
                    <TableCell className="text-right">
                      {item.dataSource ? (
                        <Badge variant="outline" className={item.dataSource === "今日" || item.dataSource.startsWith("今日") ? "bg-emerald-50 text-emerald-600" : "bg-blue-50 text-blue-600"}>
                          {item.dataSource}
                        </Badge>
                      ) : (
                        <span className="text-xs text-gray-400">-</span>
                      )}
                    </TableCell>
                    <TableCell className="w-48">
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-gray-500">{progress.toFixed(1)}%</span>
                          <span className="text-gray-400">¥{fmt(item.gmv)} / ¥{fmt(item.targetGmv)}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
                          <div className={`h-2.5 rounded-full transition-all duration-500 ${progress >= 100 ? "bg-emerald-500" : progress >= 50 ? "bg-blue-500" : progress >= 25 ? "bg-yellow-500" : "bg-red-500"}`} style={{ width: `${Math.min(progress, 100)}%` }} />
                        </div>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
