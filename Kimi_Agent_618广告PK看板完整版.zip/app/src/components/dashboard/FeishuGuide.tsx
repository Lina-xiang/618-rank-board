import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { FileSpreadsheet, BookOpen } from "lucide-react";

export function FeishuGuide() {
  return (
    <Card className="border-0 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-bold flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-blue-500" />
          飞书多维表格配置指南
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-100">
          <div className="flex items-start gap-2">
            <BookOpen className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-blue-700 space-y-1">
              <p className="font-medium">数据流转方式</p>
              <p>运营同学在飞书多维表格中维护各品牌的消耗/ROI/GMV数据，看板通过飞书 API 自动同步。</p>
              <p className="text-xs mt-1 font-medium">飞书表格更新 → 每小时第10分钟自动同步 / 手动立即同步</p>
            </div>
          </div>
        </div>

        <Accordion type="single" collapsible className="w-full">
          <AccordionItem value="step1">
            <AccordionTrigger className="text-sm font-medium hover:no-underline">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-600">步骤 1</Badge>
                创建飞书多维表格
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-gray-600 space-y-2 px-2">
              <p>在飞书中创建一个多维表格，包含以下列：</p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs border rounded">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-3 py-2 text-left border">列名（建议）</th>
                      <th className="px-3 py-2 text-left border">字段类型</th>
                      <th className="px-3 py-2 text-left border">说明</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr><td className="px-3 py-2 border font-medium">品牌</td><td className="px-3 py-2 border">文本</td><td className="px-3 py-2 border">品牌名称，用于匹配看板中的品牌</td></tr>
                    <tr><td className="px-3 py-2 border font-medium">团队</td><td className="px-3 py-2 border">文本</td><td className="px-3 py-2 border">所属团队（可选）</td></tr>
                    <tr><td className="px-3 py-2 border font-medium">消耗</td><td className="px-3 py-2 border">数字</td><td className="px-3 py-2 border">广告投放花费（元）</td></tr>
                    <tr><td className="px-3 py-2 border font-medium">ROI</td><td className="px-3 py-2 border">数字</td><td className="px-3 py-2 border">投入产出比（GMV/消耗）</td></tr>
                    <tr><td className="px-3 py-2 border font-medium">GMV</td><td className="px-3 py-2 border">数字</td><td className="px-3 py-2 border">广告成交额（元）</td></tr>
                    <tr><td className="px-3 py-2 border font-medium">时间</td><td className="px-3 py-2 border">日期</td><td className="px-3 py-2 border">数据记录时间</td></tr>
                  </tbody>
                </table>
              </div>
              <p className="text-xs text-orange-500 mt-1">只需要消耗、ROI、GMV 三列核心数据，其他列按需添加。</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="step2">
            <AccordionTrigger className="text-sm font-medium hover:no-underline">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-600">步骤 2</Badge>
                创建飞书应用并获取凭证
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-gray-600 space-y-2 px-2">
              <p>1. 访问 <a href="https://open.feishu.cn/app" target="_blank" rel="noopener noreferrer" className="text-blue-600 underline">飞书开放平台</a></p>
              <p>2. 点击「创建企业自建应用」，填写名称（如「618数据看板」）</p>
              <p>3. 进入应用 →「凭证与基础信息」，复制 App ID 和 App Secret</p>
              <p>4. 进入「权限管理」，开通权限：</p>
              <ul className="list-disc pl-5 space-y-1">
                <li><code className="bg-gray-100 px-1 rounded">bitable:app</code> - 读写多维表格</li>
                <li><code className="bg-gray-100 px-1 rounded">bitable:app:readonly</code> - 查看多维表格</li>
              </ul>
              <p>5. 进入「版本管理与发布」→「创建版本」→「申请发布」</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="step3">
            <AccordionTrigger className="text-sm font-medium hover:no-underline">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-600">步骤 3</Badge>
                授权应用访问表格
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-gray-600 space-y-2 px-2">
              <p>1. 打开飞书多维表格</p>
              <p>2. 点击右上角「···」→「更多」→「添加文档应用」</p>
              <p>3. 搜索你的应用名称（如「618数据看板」）</p>
              <p>4. 选择「可编辑」权限，点击添加</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="step4">
            <AccordionTrigger className="text-sm font-medium hover:no-underline">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-600">步骤 4</Badge>
                在看板中配置连接
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-gray-600 space-y-2 px-2">
              <p>1. 切换到「飞书配置」标签页</p>
              <p>2. 填入 App ID 和 App Secret</p>
              <p>3. 粘贴多维表格链接到「快速提取」框，自动提取参数</p>
              <p>4. 检查字段映射是否与表格列名一致</p>
              <p>5. 点击「测试连接」验证</p>
              <p>6. 点击「保存配置」</p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="step5">
            <AccordionTrigger className="text-sm font-medium hover:no-underline">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-blue-50 text-blue-600">步骤 5</Badge>
                自动同步说明
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-sm text-gray-600 space-y-2 px-2">
              <p>配置完成后，系统会在<strong>每小时第10分钟</strong>自动从飞书同步数据。</p>
              <p>例如：10:10、11:10、12:10 ...</p>
              <p>你也可以随时点击「立即同步」按钮手动触发同步。</p>
              <div className="mt-2 p-2 bg-orange-50 rounded border border-orange-100">
                <p className="text-xs text-orange-700">运营同学只需在飞书表格中更新数据，看板会自动在每小时第10分钟刷新排名。</p>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}
